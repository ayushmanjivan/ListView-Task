//
//  DemoApp.swift
//  DemoTest
//
//  Created by developer on 23/04/24.
//

import SwiftUI
import Alamofire
import ListViewPackage

struct DemoApp: View {
    @State private var emails: [String] = []
    @State private var selectedEmail: String?
    @State private var isShowingListView: Bool = false
    
    var body: some View {
        if isShowingListView {
            ListView(emails: emails, didSelectEmail: { email in
                selectedEmail = email
                isShowingListView = false
            })
        } else {
            VStack {
                Button(action: {
                    fetchEmails()
                }) {
                    Text("Fetch Emails")
                }
                if let email = selectedEmail {
                    Text("Selected Email: \(email)")
                }
            }
        }
    }
    
    private func fetchEmails() {
        // Call API using Alamofire
        AF.request("https://reqres.in/api/users?page=1").responseDecodable(of: UserResponse.self) { response in
            guard let users = response.value?.data else { return }
            self.emails = users.map { $0.email }
            self.isShowingListView = true
        }
    }
    
    struct UserResponse: Decodable {
        let data: [User]
    }

    struct User: Decodable {
        let email: String
    }
}


struct DemoApp_Previews: PreviewProvider {
    static var previews: some View {
        DemoApp()
    }
}
