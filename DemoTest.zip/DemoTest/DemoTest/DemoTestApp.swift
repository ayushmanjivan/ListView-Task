//
//  DemoTestApp.swift
//  DemoTest
//
//  Created by developer on 22/04/24.
//

import SwiftUI

@main
struct DemoTestApp: App {
    var body: some Scene {
        WindowGroup {
            DemoApp()
        }
    }
}
